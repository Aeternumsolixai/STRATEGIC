import React from 'react';
import { TrendingUp, TrendingDown, Cylinder, RefreshCw } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface OilPrice {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
}

export default function OilWidget() {
  const [prices, setPrices] = React.useState<OilPrice[]>([]);
  const [loading, setLoading] = React.useState(true);

  const fetchPrices = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/commodity');
      if (!response.ok) throw new Error('Failed to fetch');
      const data = await response.json();
      
      const formattedData: OilPrice[] = [
        {
          symbol: 'BRENT',
          name: 'Brent',
          price: data.price + 2.50,
          change: data.changePercent,
          changePercent: data.changePercent,
        },
        {
          symbol: 'WTI',
          name: 'WTI',
          price: data.price,
          change: data.changePercent,
          changePercent: data.changePercent,
        }
      ];
      setPrices(formattedData);
    } catch (error) {
      // Fallback
      setPrices([
        { symbol: 'BRENT', name: 'Brent', price: 82.45, change: 1.24, changePercent: 1.52 },
        { symbol: 'WTI', name: 'WTI', price: 77.12, change: -0.85, changePercent: -1.09 }
      ]);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchPrices();
    const interval = setInterval(fetchPrices, 300000); // 5 minutes
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center gap-4 px-4 py-1.5 bg-slate-900/50 border border-slate-800 rounded-full backdrop-blur-sm">
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Dataset",
          "name": "Live Oil Price Benchmarks",
          "description": "Real-time pricing for Brent and WTI crude oil benchmarks.",
          "variableMeasured": ["Price", "Change Percent"],
          "isAccessibleForFree": true
        })}
      </script>
      <div className="flex items-center gap-2 pr-2 border-r border-slate-800">
        <Cylinder className={cn("w-3.5 h-3.5 text-amber-400", loading && "animate-pulse")} />
        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest whitespace-nowrap">Crude Oil Price</span>
        {loading && <RefreshCw className="w-2.5 h-2.5 text-slate-600 animate-spin ml-1" />}
      </div>
      
      <div className="flex items-center gap-6">
        {prices.map((oil) => (
          <div key={oil.symbol} className="flex items-center gap-3">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{oil.name}</span>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-slate-100">${oil.price.toFixed(2)}</span>
              <div className={cn(
                "flex items-center text-[10px] font-mono font-bold",
                oil.change >= 0 ? "text-emerald-400" : "text-red-400"
              )}>
                {oil.change >= 0 ? <TrendingUp className="w-2.5 h-2.5 mr-0.5" /> : <TrendingDown className="w-2.5 h-2.5 mr-0.5" />}
                {Math.abs(oil.changePercent).toFixed(1)}%
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
