import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Proxy for NewsAPI
  app.get("/api/news", async (req, res) => {
    const apiKey = process.env.NEWS_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "NEWS_API_KEY not configured" });
    }

    const query = req.query.q || 'Iran OR "US Navy" OR "Strait of Hormuz" OR Blockade';
    const url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(query as string)}&language=en&sortBy=publishedAt&pageSize=10&apiKey=${apiKey}`;

    try {
      const response = await fetch(url);
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("NewsAPI Proxy Error:", error);
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  // API Proxy for Trading Economics (Crude Oil)
  app.get("/api/commodity", async (req, res) => {
    try {
      console.log("Fetching crude oil data from Trading Economics...");
      const response = await fetch("https://tradingeconomics.com/commodity/crude-oil", {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
      });
      
      if (!response.ok) {
        throw new Error(`Trading Economics returned ${response.status}`);
      }

      const html = await response.text();
      
      // Extract price and change using regex from the HTML
      // Trading Economics typically has a meta tag or a specific div for the price
      // Looking for patterns like: "rose to 103.59 USD/Bbl" or data-value attributes
      
      const priceMatch = html.match(/rose to ([\d.]+) USD\/Bbl/i) || 
                         html.match(/id="lastPrice">([\d.]+)</i) ||
                         html.match(/lastPrice: ([\d.]+)/i);
                         
      const changeMatch = html.match(/up ([\d.]+)%/i) || 
                          html.match(/down ([\d.]+)%/i) ||
                          html.match(/percentChange: ([\d.-]+)/i);

      if (priceMatch) {
        const price = parseFloat(priceMatch[1]);
        const changePercent = changeMatch ? parseFloat(changeMatch[1]) * (html.includes('down') ? -1 : 1) : 0;
        
        // Return structured data similar to what the frontend expects
        res.json({
          name: "Crude Oil",
          price: price,
          changePercent: changePercent,
          unit: "USD/Bbl"
        });
      } else {
        console.warn("Could not parse price from Trading Economics HTML");
        res.status(404).json({ error: "Could not parse price data" });
      }
    } catch (error) {
      console.error("Trading Economics Scraper Error:", error);
      res.status(500).json({ error: "Failed to fetch commodity data" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
